Members:
Asmaa El-Sayed Ismail Mohamed Ali
Seham Samy El-Safty
Alaa Hosny Diab
Aya Nabil 
-------------
Roles:


Asmaa El-Sayed Ismail Mohamed Ali:
Creation of the Database 
Admin pages

--------------------------------------------------------
Seham Samy El-Safty
Active Record
Display existing posts
--------------------------------------------------------
Alaa Hosny Diab
Single post and its comments
User category
Design
Edit profile and category

--------------------------------------------------------
Aya Nabil
Home
login
comments 
users
Helping in admin panel
Design
Display existing posts
------------------------------------------------------------------ 





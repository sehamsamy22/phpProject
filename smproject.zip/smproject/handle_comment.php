<?php
$postId=$_GET['pid'];

if(isset (  $_POST['comment_submit']  )   ){
//$comment_title = $_POST['comment_title'];
$comment_title=$_POST['comment_title'];
echo $comment_title;
$comment_content = $_POST['comment_content'];
}
//validate data
//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if( mysqli_connect_errno() ){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="INSERT INTO comments values(
    NULL,
    '$comment_title',
    '$comment_content',
    '$postId',
    'draft'
)";


//die($query);
$result = mysqli_query($con,$query);
//3- check result
if(!$result){
    echo mysqli_error($con)."<br>";
    exit;
}
echo "user inserted with id=".mysqli_insert_id($con);


//4- close connection
mysqli_close($con);
header("Location: post.php?pid= $postId");


//die($result);
?>
<?php
require_once 'category.php';

$id=$_GET['catId'];
//1- connect to db
$con = mysqli_connect('localhost','root','root','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student


if(!category::delete($con,$catId)){
    $message='not deleted';
}else{
    $message="deleted";
}

//4- close connection
mysqli_close($con);
header("Location: list.php?message=$message");

?>

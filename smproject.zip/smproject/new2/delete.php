<?php
require_once 'config.php';
require_once 'vendor/php-activerecord/php-activerecord/ActiveRecord.php';
	// $dsn = 'mysql:host=localhost;dbname=smproject';
	// $user = 'root';
	// $pass = '';
	// $option = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAME utf8');
	// try {
	// 	$connect = new PDO($dsn,$user,$pass);
	// 	$connect-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  //
	// } catch (PDOException $e) {
	// 	echo "erroe".$e->getMessage();
	// }
	$field = $_POST['field'];
	$format = $_POST['format'];
	$value = $_POST['value'];
	if ($format=="Equal") {
		$post=Post::find(array('conditions' => "$field LIKE '$value%'"));
		$post->delete();

	}elseif ($format=="Begin with") {
		$post=Post::find(array('conditions' => "$field LIKE '$value%'"));
		$post->delete();
	}elseif ($format=="End with") {
		$post=Post::find(array('conditions' => "$field LIKE '$value%'"));
		$post->delete();
	}elseif ($format=="contain") {
		$post=Post::find(array('conditions' => "$field LIKE '$value%'"));
		$post->delete();
	}


	include 'delete.html';



 ?>

<?php

class Post extends ActiveRecord\model
{
    private $id;
     private $name;
     private $text;
     private $image;
     private $categoryId;
     private $postStatus;
     private $postedBy;
     private $postedAt;
}










 ?>

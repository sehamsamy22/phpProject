<?php
class User extends ActiveRecord\Model{

    private $id;
    private $username;
    private $firstName;
    private $lastName;
    private $email;
    private $password;
    private $userStatus;
    private $photo;

}

    ?>

    

<?php

require_once 'config.php';
require_once 'vendor/php-activerecord/php-activerecord/ActiveRecord.php';
	// $dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name
 // $user   = 'root';
 // $pass   = '12345';
 // $option = array(
 // 		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic
 // 	);
 // try{
 // 	$connect = new PDO($dsn,$user,$pass);
 // 	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 // 	echo "data added succefully";
 //    }
 //    catch(PDOException $e){
	// 	echo "error".$e->getMessage();
 //    }
    $name = $_POST['poster_name'];
    $text = $_POST['new_post'];
	$image = $_POST['image'];



 $post = new Post();

 $post->name=$name;
 $post->text=$text;
 $post->image=$image;
 $post->save();

	//$q= "insert into posts(name,text,image)values('$poster_name','$post','$image')";


echo "DATA added succesfully";




 ?>




 

<?php
require_once 'postsClass.php';

$id=$_GET['id'];
//1- connect to db
$con = mysqli_connect('localhost','root','12345','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student


if(!Posts::delete($con,$id)){
    $message='not deleted';
}else{
    $message="deleted";
}

//4- close connection
mysqli_close($con);
header("Location: listPost.php?message=$message");

?>

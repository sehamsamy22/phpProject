<?php
require 'postsClass.php';
$postId=$_GET['id'];
//1- connect to db
$con = mysqli_connect('localhost','root','12345','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$post= Posts::getPostByID($con,$postId);
// print_r($student);
// exit;

//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up</title>
</head>
<body>
    <form action="updatePost.php?id=<?= $post->$postId ?>" method="post">
        <label for="postStatus">postStatus:</label>
        <input type="text" name="postStatus" value="<?= $post->postStatus ?>"><br>
        <label for="categoryId">categoryId:</label>
        <input type="categoryId" name="categoryId" value="<?= $post->categoryId ?>"><br>
        <label for="postContent">postContent:</label>
        <textarea name="postContent" value="<?=$post->postText?>"></textarea><br>
        <label for="categoryId">categoryId:</label>
        <input type="text" name="categoryId" value="<?= $post->categoryId ?>"><br>
        <label for="postedBy">postedBy:</label>
        <input type="text" name="postedBy" value="<?= $post->postedBy ?>"><br>
        <label for="postedAt">postedAt:</label>
        <input type="text" name="postedAt" value="<?= $post->postedAt ?>"><br>
        postedBy

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>

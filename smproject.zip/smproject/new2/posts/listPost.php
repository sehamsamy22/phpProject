<?php
$con = mysqli_connect('localhost','root','12345','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="select * from posts";
// die($query);
$posts = mysqli_query($con,$query);
//3- check result
if(!$posts){
    echo mysqli_error($con)."<br>";
    exit;
}


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>List</title>
</head>

<body>
   <h2>List of posts</h2>
   <table>
       <tr>
         <th>Title</th>
         <th>Category</th>
         <th>Content</th>
         <th>PostedBy</th>
         <th>PostedAt</th>
         <th>PostStatus</th>
       </tr>
        <?php
            while ($post = mysqli_fetch_assoc($students)) {
               ?>
                <tr>
                  <td><?= $post['name'] ?></td>
                  <td><?= $post['categoryId'] ?></td>
                  <td><?= $post['postText'] ?></td>
                  <td><?= $post['postedBy'] ?></td>
                  <td><?= $post['postedAt'] ?></td>
                  <td><?= $post['postStatus'] ?></td>
                    <td>
                        <a href="editPost.php?id=<?= $post['id']?>">edit</a>
                        <a href="deletePost.php?id=<?= $post['id'] ?>">delete</a>
                    </td>
                </tr>
               <?php
            }
        ?>
   </table>
   <a href="welcome.php">Go to home page</a>
</body>
</html>

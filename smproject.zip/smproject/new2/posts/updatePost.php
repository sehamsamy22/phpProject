<?php
require_once 'postsClass.php';

ob_start();
$id=$_GET['id'];

/* $postId,
 $postStatus,
 $categoryId,
 $postContent,
 $postedBy,
 $postedAt,
 $postTitle,
 $image*/

 $postId= $_POST['id'];
 $postStatus= $_POST['postStatus'];
 $categoryId= $_POST['categoryId'];
 $postContent= $_POST['postText'];
 $postedBy= $_POST['postedBy'];
 $postedAt= $_POST['postedAt'];
 $postTitle= $_POST['name'];
 $image= $_POST['image'];



//1- connect to db
$con = mysqli_connect('localhost','root','12345','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$post=new Posts( $postId,$postStatus,$categoryId,$postContent,$postedBy,$postedAt,$postTitle,$image);
$result = $post->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: listPost.php?message=$message");

?>

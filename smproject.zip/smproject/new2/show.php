 <?php
 require_once 'config.php';

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<tr>" . parent::current(). "</tr>";
    }

    function beginChildren() {
        echo "<div  width:500px;
                 height:200px;
        background-color:blue;>";
    }

    function endChildren() {
        echo "</div>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "smproject";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, name, text,image FROM posts");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v."\n";

    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

// $result=Post::find('all');
// foreach(new TableRows(new RecursiveArrayIterator($result)) as $k=>$v) {
//         echo $v."\n";
// }
// echo "</table>";
?>
<html>

  <style >
  div{
    width:500px;
    height:150px;
    background-color:lightblue;
    padding-left:100px;
border: 1px solid black;
padding-top: 30px;
  }
  </style>

</html>


<?php
$dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name
 $user   = 'root';
 $pass   = '12345';
 $option = array(
 		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic
 	);
 try{
 	$connect = new PDO($dsn,$user,$pass);
 	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

    }
    catch(PDOException $e){
		echo "error".$e->getMessage();
    }

    $username = $_POST['username'];
    $email = $_POST['email'];
	$password = $_POST['password'];
	$q= "insert into users(username,email,password)values('$username','$email','$password')";
	$connect->exec($q);
	echo "DATA added succesfully";
	include 'index.php';



 ?>

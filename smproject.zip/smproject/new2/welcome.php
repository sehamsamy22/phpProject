<?php
require_once 'config.php';
require_once 'vendor/php-activerecord/php-activerecord/ActiveRecord.php';
	// $dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name
	//  $user   = 'root';
	//  $pass   = '12345';
	//  $option = array(
	//  		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic
	//  	);
	//  try{
	//  	$connect = new PDO($dsn,$user,$pass);
	//  	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  //
	//     }
	//     catch(PDOException $e){
	// 		echo "error".$e->getMessage();
	//     }

 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Welcome</title>
	<link rel="stylesheet" href="css/bootstrap.css">

	<link rel="stylesheet" href="css/style2.css"/>

</head>
<body>
		<div class="container-fulflied">

			<div class="dv1 btn-success">
			<div class="col-md-1"></div>
			<div class="col-md-3">
				<h3> <?php echo $name ?></h1>

			</div>

			<div class="col-md-3">

				<h1 class="text-center hidden="-sm" ">WELCOME</h1>
			</div>
			<div class="col-md-3"></div>
			<div class="col-md-1">
				<h2><a href = "logout.php">SignOut</a></h2>
			</div>




		</div>
		<div class="container-fulflied">
			<div class="col-md-4 dv2 btn-default text-center">
				<h1 class="">Your Options</h1>
				<ul class="list-group">



					<li class="list-group-item list-group-item-info"><a href="show.php">Added post</a></li><br>



					 <li class="list-group-item list-group-item-danger"><a href="delete.html">Deleted posts</a></li><br>


				</ul>


			</div>

			<div class="col-md-8 dv3 btn-primary">
			<h1 class="text-center">Diccuss with the world </h1>
			<form action="posts.php" method="post">
				<div class="form-group">
					<label for="poster_name">Your Name</label>
               <input type="text" name="poster_name" class="form-control" id="firstname" placeholder="John"/>

				</div>


                <div class="form-group">
					  <label for="post">YOUR post</label>
					  <textarea class="form-control" rows="5" id="post" name="new_post"></textarea>
					</div>

					<div class="form-group">
					  <label for="image">YOUR photo</label>
					  <input type="file" name="image">

					</div>

					<button class="btn btn-primary btn-lg">Post</button>


			</form>




			</div>



		</div>


     <script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery.js"></script>
</body>
</html>

<?php
// $catId=$_GET['cid'];
$postId=$_GET['pid'];
// start content
 //1- connect to db
 $con = mysqli_connect('localhost','root','000000','smproject');
 if(mysqli_connect_errno()){
     echo mysqli_connect_error()."<br>";
     exit;
 }
 // echo "connection success<br>";
 //2- insert student
 $query="select * from posts where id  ='$postId'";
 // die($query);
 $posts = mysqli_query($con,$query);
 //3- check result
 if(!$posts){
     echo mysqli_error($con)."<br>";
     exit;
 }
 
 
 //4- close connection
 mysqli_close($con);



?>

<html>
    <head><title>Products</title>
    <link href="css2/style.css" rel="stylesheet" />
    </head>
    <body>
        <!-- start header -->
        <div id="header">
         <div id="header-container">
                <a href="home.html" id="logo"><img src="img/logo.png" alt="logo" width="50" height="50" /></a>
            
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="products.html">Prouducts</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="register.html">Register</a></li>
                <li><a href="register.html" class="sign">Login</a></li>
                
            </ul>
          </div>
        </div>
        <!-- end header -->
        
        <!-- start content-->
        <div id="products">
            <div id="content-container">
                
            <?php
            while ($post = mysqli_fetch_assoc($posts)) {
               ?>
            
           
        



               <div class="oneproduct">
                


                 <h1>Title:<?php echo $post['name']?></h1>

                 <p class="post">
                 <?php echo $post['text']?>
                  </p>
                  <a>postedAt <?php echo $post['postedAt']?></a>
                 
               </div>
               
              
               <?php
            }
        ?>
   
               
               
               
               
              
               
               
               
               
               
               
               
                
                
                
            </div>
            
        </div>
        
        <!-- start content-->
        
        
        
        <!-- start footer -->
        <div id="footer">
            <div id="footer-container">
            <ul>
                <li><a href="#"><img src="img/fb.png" /></a></li>
                <li><a href="#"><img src="img/g.png" /></a></li>
                <li><a href="#"><img src="img/tw.png" /></a></li>
                <li><a href="#"><img src="img/vimo.png" /></a></li>
            </ul>
            <p>&copy; iti 2017 All Right Reserved</p>
            </div>
        </div>
        <!-- end footer -->
    </body>
</html>

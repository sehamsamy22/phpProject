<?php 
define('FIRSTNAME', 'sayed');
define('LASTNAME', 'tarek');
define('EMAIL', 'sayed12@yahoo.com');
define('PASSWARD', '0123456');
if ($_POST["firstname"]===FIRSTNAME && $_POST["lastname"]===LASTNAME && $_POST["email"]===EMAIL & $_POST["password"]===PASSWARD) {
	session_start();
	echo "
       <center style=\"color:white;\">
       <h1>Welcome To Our WebSite $_POST[firstname]<br>
       Thanks For Giving Us Information About You</h1><br>
       <h2>Now We Are Going To Display Your Information</h2><br>
	   <h3 style=\"color:yellowgreen;\">Your Full Name Is: $_POST[firstname] $_POST[lastname] </h3>
	   <h3 style=\"color:yellowgreen;\">Your Email is:$_POST[email]</h3>
	   <h2>Thanks for Giving Us Some Part Of Your Time</h2>
	   <h1>Now You Can LogOut</h1>
       </center>
	     ";
}
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Document</title>
 </head>
 <body style="background:black;">
 <center>
 	<form action="out.php" method="post">
 		<button style="width:150px; height:40px; border: none; font-size: 20px; color: white; border-radius: 5px; background-color:yellowgreen;">LogOut</button>

 	</form>

 </center>
 	
 </body>
 </html>
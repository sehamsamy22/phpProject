<?php
// $catId=$_GET['cid'];
$postId=$_GET['pid'];
// start content
 //1- connect to db
 $con = mysqli_connect('localhost','root','000000','smproject');
 if(mysqli_connect_errno()){
     echo mysqli_connect_error()."<br>";
     exit;
 }
 // echo "connection success<br>";
 //2- insert student
 $query="select * from posts where id  ='$postId'";
 $comment_query="select * from comments where postid  ='$postId'and postStatus='approved' ";
 // die($query);
 $posts = mysqli_query($con,$query);
 $comments = mysqli_query($con,$comment_query);
 //3- check result
 if(!$posts){
     echo mysqli_error($con)."<br>";
     exit;
 }
 
 
 //4- close connection
 mysqli_close($con);



?>


<html>
    <head><title>Products</title>
    <link href="css2/style.css" rel="stylesheet" />
    </head>
    <body>
        <!-- start header -->
        <div id="header">
         <div id="header-container">
                <a href="home.html" id="logo"><img src="img/logo.png" alt="logo" width="50" height="50" /></a>
            
            <ul>
                <li><a href="home.html">Home</a></li>
               
                <li><a href = "logout.php" class="sign">Logout</a></li>
                
            </ul>
          </div>
        </div>
        <!-- end header -->
        
        <!-- start content-->
        <div id="products">
            <div id="content-container">
                
            <?php
            while ($post = mysqli_fetch_assoc($posts)) {
               ?>
               <div class="oneproduct">
                


                 <h1>Title:<?php echo $post['name']?></h1>

                 <p class="post">
                 <?php echo $post['text']?>
                 <br>
                 
                  </p>
                  <p>

                  <h3>Posted By<?php echo $post['postedBy']?>  and posted at <?php echo $post['postedAt']?> </h3>
                  </p>
                 
                  <h5>comments</h5>
                  <?php
            while ($comment = mysqli_fetch_assoc($comments)) {
               ?>
                  <div class="comment">
                  <p><h3 class="titles">title:
                      <?php echo $comment['title']?> </h3>
                      <p class="comment_content">
                      <?php echo $comment['comment']?>
                       </p>
                      <br><h3>comented by : <?php echo $comment['comId']?></h3></p>
                  </div>
                  
                  <?php
            }
        ?> 
                <form method="post" class="comment_form" action="handle_comment.php?pid=<?=$postId ?>">
                    <h3>Add Comment</h3>
                  <input type="text" placeholder="title" class="comment" name="comment_title" /><br><br><br>
                  <textarea class="comment" name="comment_content" placeholder="write your comment ....."></textarea><br><br><br>
                  
                  <input type="submit" class="addcomment" value="add comment" name="comment_submit" />
                </form>
               </div>
               
              
               
               
               
               
               
               <?php
            }
        ?> 
               
               
               
               
               
               
               
                
                
                
            </div>
            
        </div>
        
        <!-- start content-->
        
        
        
        <!-- start footer -->
        <div id="footer">
            <div id="footer-container">
            <ul>
                <li><a href="#"><img src="img/fb.png" /></a></li>
                <li><a href="#"><img src="img/g.png" /></a></li>
                <li><a href="#"><img src="img/tw.png" /></a></li>
                <li><a href="#"><img src="img/vimo.png" /></a></li>
            </ul>
            <p>&copy; iti 2017 All Right Reserved</p>
            </div>
        </div>
        <!-- end footer -->
    </body>
</html>
<?php 
 $dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name 
 $user   = 'root';
 $pass   = '000000';
 $option = array(
 		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic 
 	);
 try{
 	$connect = new PDO($dsn,$user,$pass);
 	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 	echo "data added succefully";
    }
    catch(PDOException $e){
		echo "error".$e->getMessage();
    }
    $poster_name = $_POST['poster_name'];
    $post = $_POST['new_post'];
	$image = $_POST['image'];
	$cats_select=$_POST['cats_select'];
	echo $cats_select;
	$q= "insert into posts(name,text,image,categoryId,postStatus)values('$poster_name','$post','$image','$cats_select','draft')";
	$connect->exec($q);
	echo "DATA added succesfully";
	header('location:all_posts.php');


	

 ?>
 



 
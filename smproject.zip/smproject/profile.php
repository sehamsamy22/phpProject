







<?php
//$userName=$_GET['userName'];
//echo $userName;
$userId=1;
//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="select * from users where id=$userId";
$query2="select * from categories ";
$cats = mysqli_query($con,$query2);
// die($query);
$students = mysqli_query($con,$query);
//var_dump($students);
//3- check result
if(!$students){
    echo mysqli_error($con)."<br>";
    exit;
}
/*
while($student=mysqli_fetch_assoc($students)){
print_r($student);

}*/

//$student=mysqli_fetch_assoc($students);
//print_r($student);

//4- close connection
mysqli_close($con);
?>


<html>
    <head><title>About</title>
    <link href="css2/style.css" rel="stylesheet" />
    </head>
    <body>
    




        <!-- start header -->
        <div id="header">
         <div id="header-container">
                <a href="home.html" id="logo"><img src="img/logo.png" alt="logo" width="50" height="50" /></a>
            
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="products.html">Prouducts</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="register.html">Register</a></li>
                <li><a href = "logout.php" class="sign">Logout</a></li>
                
            </ul>
          </div>
        </div>
        <!-- end header -->
        
        <!-- start content-->
        <div id="about">
            <div id="content-container">
                
                
                
                
                <div id="staff">
                    
                <?php
           if( $student = mysqli_fetch_assoc($students)){
              
                //var_dump($student);
                $myPhoto='images/'.$student['photo'];
               //var_dump($myPhoto); 
               //var_dump($student['fname']);   
               ?>

 
                    
                    <div class="one-staff">
                        <img src="<?= 'images/'.$student['photo'] ?>"/>
                        <h3 name="profname" class="profName"><?= $student['firstName']?> <?=$student['lastName'] ?></h3>
                        <p name="email" class="profEmail" ><?= $student['email']?></p>
                        <a href="editPro.php?id=<?= $userName?>" class="editProf" name="editProf" >edit</a>
                    </div>
                    
                   

                            

                </div>
                
                
            </div>
            
        </div>
        
        <!-- start content-->
        
        
        <!-- start footer -->
        <div id="footer">
            <div id="footer-container">
                <h2 class="cats" >Categories</h2>
            <ul class="cat">
            <?php
            while ($cat = mysqli_fetch_assoc($cats)) {
               ?>
     <li><a href="cat.php?cid=<?php echo $cat['catId'] ?> " ><?php echo $cat['name'] ?></a></li>
     
            <?php  } ?>
                
            </ul>
            <p>&copy; iti 2017 All Right Reserved</p>
            </div>
        </div>
        <!-- end footer -->
    </body>
</html>
<?php
           }
           else
           
{

    var_dump($student);
    echo 'hi';
}
            
           

        ?>

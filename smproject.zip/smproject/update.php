<?php

$userId=$_GET['id'];
if(isset($_POST['update'])){
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$password=$_POST['password'];
$email=$_POST['email'];


}


if(isset($_FILES['image'])){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name'];
    $file_type=$_FILES['image']['type'];
    $file_ext=strtolower(explode('.',$_FILES['image']['name'])[1]);
    $current_time=time();
    $new_name = $current_time. $file_name;
    $image_path='images/'.$new_name;
    //print_r($_FILES);
    //echo 'the date is'. time();
    
    $expensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$expensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    
    if($file_size > 2097152){
       $errors[]='File size must be excately 2 MB';
    }
    
    if(empty($errors)==true){
      //  move_uploaded_file($file_tmp,"/home/alaa/".$file_name);
      // move_uploaded_file($file_tmp,$file_name);
      move_uploaded_file($file_tmp,$image_path);
       
       //echo "Success";
    }else{
       print_r($errors);
       echo'hi here';
    }
 }



//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="UPDATE users
  set 
  firstName='$fname',
  lastName='$lname',
  password='$password',
  email='$email',
  photo='$new_name'

 where id=$userId";
//die($query);
$result = mysqli_query($con,$query);
//die($result);
//var_dump($result);

//3- check result
if(!$result){
        echo mysqli_error($con);
        exit;
    }else if(mysqli_affected_rows($con)>0){
        echo "USER updated<br>";
    }else{
        echo "USER Not Found<br>";
    }
    // while($student=mysqli_fetch_assoc($students)){
    //    // print_r($student);
       
    //    } 

    header("Location: profile.php?pid= $userId");
//4- close connection
mysqli_close($con);

?>




